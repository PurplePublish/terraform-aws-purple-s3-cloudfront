const {S3Client, GetObjectCommand, PutObjectCommand} = require('@aws-sdk/client-s3');
const sharp = require('sharp');
const Helpers = require('./helpers');
const smartcrop = require('smartcrop-sharp');

/**
 * For use in referencing functions from this file
 *
 * @type {object}
 */
const self = module.exports = {};

/**
 * Get the dimensions from a string or array of strings.
 */
function getDimArray(dims, zoom = 1) {
    let dimArr = typeof dims === 'string' ? dims.split(',') : dims;
    return dimArr.map(v => Math.round(Number(v) * zoom) || null);
}

/**
 * Clamp a value between a min and max.
 */
function clamp(val, min, max) {
    return Math.min(Math.max(Number(val), min), max);
}

/**
 * Apply a logarithmic compression to a value based on a zoom level.
 * return a default compression value based on a logarithmic scale
 * defaultValue = 100, zoom = 2; = 65
 * defaultValue = 80, zoom = 2; = 50
 * defaultValue = 100, zoom = 1.5; = 86
 * defaultValue = 80, zoom = 1.5; = 68
 */
function applyZoomCompression(defaultValue, zoom) {
    const value = Math.round(defaultValue - (Math.log(zoom) / Math.log(defaultValue / zoom)) * (defaultValue * zoom));
    const min = Math.round(defaultValue / zoom);
    return clamp(value, min, defaultValue);
}

/**
 * Parse a URL and setup different options that can be passed along our Promise chain
 *
 * @param {string} url The URL to parse
 * @param {string} bucketRegion
 * @param {string} bucketName
 * @return {Promise|object} Returns a promise that resolves to an object with various data about the image
 */
module.exports.setup = async function (url, bucketRegion, bucketName) {
    // Remove preceding slash
    url = url.replace(/^\/+/g, '');
    const originalURL = url;

    // S3 Setup
    self.config = {
        region: bucketRegion,
        bucket: bucketName
    }

    self.s3 = new S3Client({
        region: bucketRegion,
    });

    let parts = originalURL.split('?');
    let path = parts[0];
    let querystring = parts[1];
    let params = Helpers.queryStringToJSON(querystring);
    let newQuerystring = Helpers.JSONToQueryString(params);
    newQuerystring = Helpers.sanitizeQueryString(newQuerystring);

    // Transform the path for how we store resized versions on S3
    let newPath = 'resized/' + path;
    let newURL = newPath + '_' + newQuerystring;

    let returnObj = {
        originalURL: originalURL,
        path: path,
        querystring: params,
        S3Path: newPath,
        S3Querystring: newQuerystring,
        S3Key: newURL,
    };

    // Make sure we're dealing with a supported file extension
    const originalExtension = path.split('.').pop().toLowerCase();
    const allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    if (allowedExtensions.indexOf(originalExtension) === -1) {
        returnObj.code = 'invalid-extension';
        returnObj.reason = originalExtension + ' is not an allowed file extension!';
        throw returnObj;
    }

    let matchingKeys = Object.keys(params);
    if (matchingKeys.length === 0) {
        returnObj.code = 'invalid-query-string';
        returnObj.reason = 'No valid query strings were used: ' + Object.keys(params);
        throw returnObj;
    }

    return returnObj;
};

/**
 * Check if the image is already cached on S3 based on the query string
 *
 * @param  {object} data Data about the image from setup()
 * @return {Promise|object} Returns a promise that resolves to an object with various data about the image
 */
module.exports.checkIfCached = async function (data) {
    console.log('checkIfCached');
    if (!('S3Key' in data)) {
        data.code = 'no-s3-key';
        data.reason = 'No S3 Key was passed to checkIfCached';
        throw data;
    }
    try {
        data.obj = await self.getFromS3(data.S3Key);
        data.code = 'found-on-s3';
    } catch {
        // Nothing in cache so keep going down the Promise chain...
        return data;
    }
    // If found in S3, propagate the data as a rejection
    throw data;
};

/**
 * Get the original, querystring-less image from S3
 *
 * @param  {object} data Data about the image from setup()
 * @return {Promise|object} Returns a promise that resolves to an object with various data about the image
 */
module.exports.getOriginal = async function (data) {
    console.log('getOriginal');
    if (!('path' in data)) {
        data.code = 'no-path';
        data.reason = 'No path was passed to getOriginal';
        throw data;
    }
    try {
        data.obj = await self.getFromS3(data.path);
        return data;
    } catch (err) {
        console.log(err);
        // The original image wasn't found on S3
        data.code = 'original-not-found-from-s3';
        throw data;
    }
};

/**
 * Save the processed image back to S3 in a new /resized/ directory
 *
 * @param  {object} data Data about the image from setup()
 * @return {Promise|object} Returns a promise that resolves to an object with various data about the image
 */
module.exports.cacheProcessedImage = async function (data) {
    console.log('cacheProcessedImage');
    try {
        let args = {
            key: data.S3Key,
            body: data.obj.Body,
            ContentType: data.obj.ContentType
        };
        await self.putToS3(args);
        data.code = 'cached-processed-image';
        data.reason = 'The processed image was saved to S3';
        return data;
    } catch (err) {
        data.code = 'processed-image-not-cached';
        data.reason = 'The processed image couldn\'t be cached on S3';
        console.log(err);
        throw data;
    }
};

/**
 * Helper for making a S3 read request
 *
 * @param  {string} key Path to the image in the S3 bucket
 * @return {Promise|object} Returns a promise that resolves to data about the S3 file
 */
module.exports.getFromS3 = async function (key) {
    const config = self.config;
    const command = new GetObjectCommand({
        Bucket: config.bucket,
        Key: key,
    });
    return await self.s3.send(command);
}

/**
 * helper for making a S3 write request
 *
 * @param  {object} args Object with the body of the file to be saved and the key of where the file should live in the S3 bucket
 * @return {Promise|object} Returns a promise that resolves to data about the S3 file
 */
module.exports.putToS3 = async function (args) {
    let expiry = new Date();
    expiry.setFullYear(expiry.getFullYear() + 1);
    let params = {
        Bucket: self.config.bucket,
        Key: decodeURIComponent(args.key),
        Body: args.body,
        CacheControl: 'max-age=31536000',
        Expires: expiry,
        ACL: 'public-read'
    };
    if ('ContentType' in args) {
        params.ContentType = args.ContentType;
    }
    const command = new PutObjectCommand(params);
    return await self.s3.send(command);
};

/**
 * Process an image based on the query strings passed to the URL
 *
 * @param  {object} data Data about the image from setup()
 * @return {Promise|object} Returns a promise that resolves to an object with various data about the image
 */
module.exports.processImage = async function (data) {
    console.log('processImage');
    let buffer = Buffer.from(await data.obj.Body.transformToByteArray());
    let args = data.querystring;

    const image = sharp(buffer).withMetadata();
    // check we can get valid metadata
    const metadata = await image.metadata();

    // Set content type
    switch (metadata.format) {
        case 'jpg':
        case 'jpeg':
            data.obj.ContentType = 'image/jpeg';
            break;

        case 'png':
            data.obj.ContentType = 'image/png';
            break;

        case 'gif':
            data.obj.ContentType = 'image/gif';
            break;

        case 'webp':
            data.obj.ContentType = 'image/webp';
            break;
    }

    // auto rotate based on orientation EXIF data.
    image.rotate();
    // validate args, remove from the object if not valid
    const errors = [];
    if (args.w) {
        if (!/^[1-9]\d*$/.test(args.w)) {
            delete args.w;
            errors.push('w arg is not valid');
        }
    }
    if (args.h) {
        if (!/^[1-9]\d*$/.test(args.h)) {
            delete args.h;
            errors.push('h arg is not valid');
        }
    }
    if (args.quality) {
        if (!/^[0-9]{1,3}$/.test(args.quality) ||
            args.quality < 0 ||
            args.quality > 100) {
            delete args.quality;
            errors.push('quality arg is not valid');
        }
    }
    if (args.resize) {
        if (!/^\d+(px)?,\d+(px)?$/.test(args.resize)) {
            delete args.resize;
            errors.push('resize arg is not valid');
        }
    }
    if (args.crop_strategy) {
        if (!/^(smart|entropy|attention)$/.test(args.crop_strategy)) {
            delete args.crop_strategy;
            errors.push('crop_strategy arg is not valid');
        }
    }
    if (args.gravity) {
        if (!/^(north|northeast|east|southeast|south|southwest|west|northwest|center)$/.test(args.gravity)) {
            delete args.gravity;
            errors.push('gravity arg is not valid');
        }
    }
    if (args.fit) {
        if (!/^\d+(px)?,\d+(px)?$/.test(args.fit)) {
            delete args.fit;
            errors.push('fit arg is not valid');
        }
    }
    if (args.crop) {
        if (!/^\d+(px)?,\d+(px)?,\d+(px)?,\d+(px)?$/.test(args.crop)) {
            delete args.crop;
            errors.push('crop arg is not valid');
        }
    }
    if (args.zoom) {
        if (!/^\d+(\.\d+)?$/.test(args.zoom)) {
            delete args.zoom;
            errors.push('zoom arg is not valid');
        }
    }
    if (args.webp) {
        if (!/^0|1|true|false$/.test(args.webp)) {
            delete args.webp;
            errors.push('webp arg is not valid');
        }
    }
    if (args.lb) {
        if (!/^\d+(px)?,\d+(px)?$/.test(args.lb)) {
            delete args.lb;
            errors.push('lb arg is not valid');
        }
    }
    // crop (assumes crop data from original)
    if (args.crop) {
        const cropValuesString = typeof args.crop === 'string' ? args.crop.split(',') : args.crop;
        // convert percentages to px values
        const cropValues = cropValuesString.map(function (value, index) {
            if (value.indexOf('px') > -1) {
                return Number(value.substring(0, value.length - 2));
            } else {
                return Number(Number(metadata[index % 2 ? 'height' : 'width'] * (Number(value) / 100)).toFixed(0));
            }
        });
        image.extract({
            left: cropValues[0],
            top: cropValues[1],
            width: cropValues[2],
            height: cropValues[3],
        });
    }
    // get zoom value
    const zoom = parseFloat(args.zoom || '1') || 1;
    // resize
    if (args.resize) {
        // apply smart crop if available
        if (args.crop_strategy === 'smart' && !args.crop) {
            const cropResize = getDimArray(args.resize);
            const rotatedImage = await image.toBuffer();
            const result = await smartcrop.crop(rotatedImage, {
                width: cropResize[0],
                height: cropResize[1],
            });
            if (result && result.topCrop) {
                image.extract({
                    left: result.topCrop.x,
                    top: result.topCrop.y,
                    width: result.topCrop.width,
                    height: result.topCrop.height,
                });
            }
        }
        // apply the resize
        args.resize = getDimArray(args.resize, zoom);
        image.resize({
            width: args.resize[0],
            height: args.resize[1],
            withoutEnlargement: true,
            position: (args.crop_strategy !== 'smart' && args.crop_strategy) || args.gravity || 'centre',
        });
    } else if (args.fit) {
        const fit = getDimArray(args.fit, zoom);
        image.resize({
            width: fit[0],
            height: fit[1],
            fit: 'inside',
            withoutEnlargement: true,
        });
    } else if (args.lb) {
        const lb = getDimArray(args.lb, zoom);
        image.resize({
            width: lb[0],
            height: lb[1],
            fit: 'contain',
            // default to a black background to replicate Photon API behavior
            // when no background colour specified
            background: args.background || 'black',
            withoutEnlargement: true,
        });
    } else if (args.w || args.h) {
        image.resize({
            width: Number(args.w) * zoom || undefined,
            height: Number(args.h) * zoom || undefined,
            fit: args.crop ? 'cover' : 'inside',
            withoutEnlargement: true,
        });
    }
    // set default quality slightly higher than sharp's default
    if (!args.quality) {
        args.quality = applyZoomCompression(82, zoom);
    }
    // allow override of compression quality
    if (args.webp) {
        image.webp({
            quality: Math.round(clamp(args.quality, 0, 100)),
        });
        data.obj.ContentType = 'image/webp';
    } else if (metadata.format === 'jpeg') {
        image.jpeg({
            quality: Math.round(clamp(args.quality, 0, 100)),
        });
    } else if (metadata.format === 'png') {
        // Compress the PNG.
        image.png({
            palette: true,
        });
    }
    // send image
    try {
        const img = await image.toBuffer();
        data.code = 'processed-image';
        data.obj.Body = img;
        return data;
    } catch (err) {
        data.code = 'error-processing-image';
        data.reason = err;
        throw data;
    }
};
