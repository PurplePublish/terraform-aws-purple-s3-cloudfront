const tachyon = require('./tachyon');

exports.handler = async function (event, context) {
    const request = event.Records[0].cf.request;
    const customHeaders = request.origin.s3.customHeaders;
    const region = customHeaders["x-aws-s3-region"][0].value;
    const bucket = customHeaders["x-aws-s3-bucket"][0].value;

    /**
     * Helper function to return the original request back to CloudFront
     */
    function sendUnmodifiedResponse() {
        return request;
    }

    // If no query strings then there is nothing to do...
    if (!request.querystring) {
        return sendUnmodifiedResponse();
    }

    /**
     * Handles the response when the Promise chain completes without any rejections
     *
     * @param  {object} data Data passed from the Promise chain
     * @return {request}    Modified request to send back to CloudFront
     */
    function handlePromiseSuccess(data) {
        console.log('Promise Success!');
        if (!('S3Key' in data)) {
            return sendUnmodifiedResponse();
        }

        request.uri = '/' + data.S3Key;
        request.querystring = '';
        console.log('RESULT!!!');
        console.log(JSON.stringify(request));
        return request;
    }

    /**
     * Handles the response when the Promise chain completes with a rejection
     *
     * @param  {object} data Data passed from the Promise chain
     * @return {request}    Request to send back to CloudFront
     */
    function handlePromiseError(data) {
        console.log('Promise Error!');
        switch (data.code) {
            case 'found-on-s3':
            case 'cached-processed-image':
                return handlePromiseSuccess(data);
        }
        console.log(data);
        return sendUnmodifiedResponse();
    }

    const requestURL = request.uri + '?' + request.querystring;
    return await tachyon.setup(requestURL, region, bucket)
        .then(tachyon.checkIfCached)
        .then(tachyon.getOriginal)
        .then(tachyon.processImage)
        .then(tachyon.cacheProcessedImage)
        .then(handlePromiseSuccess)
        .catch(handlePromiseError);
};
